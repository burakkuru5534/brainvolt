/// App-wide values created before the widget tree in `main.dart` and
/// injected with `ProviderScope.overrides` (Riverpod doubles as DI, ADR-0003).
library;

import 'package:flutter/foundation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'config.dart';

part 'providers.g.dart';

const _injected =
    'is created in main() and injected via ProviderScope.overrides';

/// Build-time configuration.
@Riverpod(keepAlive: true)
AppConfig appConfig(Ref ref) =>
    throw UnimplementedError('appConfigProvider $_injected');

/// Shared preferences (locale override, onboarding flags).
@Riverpod(keepAlive: true)
SharedPreferences sharedPreferences(Ref ref) =>
    throw UnimplementedError('sharedPreferencesProvider $_injected');

/// "version+build", sent as X-App-Version (conventions.md §2).
@Riverpod(keepAlive: true)
String appVersion(Ref ref) =>
    throw UnimplementedError('appVersionProvider $_injected');

/// `android` or `ios`, sent as X-Platform and in session/device bodies.
@Riverpod(keepAlive: true)
String devicePlatform(Ref ref) =>
    defaultTargetPlatform == TargetPlatform.iOS ? 'ios' : 'android';

/// Riverpod retry policy of the app: never retry failed providers
/// automatically (`ProviderScope.retry`).
Duration? noRetry(int retryCount, Object error) => null;
